package com.javaguides.lifestyledelicioswebApp.service;

import com.javaguides.lifestyledelicioswebApp.model.UsersModel;
import com.javaguides.lifestyledelicioswebApp.repository.UserRepository;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsersService {

    private final  UserRepository userRepository;

    public UsersService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }
    public UsersModel registerUser(String login, String password, String email, String name, String surname, String phoneNumber) {
        if (login != null && password != null) {
            if (userRepository.findByLogin(login).isPresent()) {
                System.out.println("User already exists");
                return null;
            }

            UsersModel user = new UsersModel();
            user.setLogin(login);
            user.setPassword(password); // Make sure to hash the password before setting it
            user.setEmail(email);
            user.setName(name);
            user.setSurname(surname);
            user.setPhoneNumber(phoneNumber);

            return userRepository.save(user);
        } else {
            return null;
        }
    }


    public UsersModel authenticate(String login, String password) {
        return userRepository.findByLoginAndPassword(login,password).orElse(null);
    }

    public void updateUser(UsersModel updatedUser) {
        UsersModel existingUser = userRepository.findById(updatedUser.getId())
                .orElseThrow(() -> new UsernameNotFoundException("User not found with id: " + updatedUser.getId()));
        existingUser.setSurname(updatedUser.getSurname());
        // Update other necessary fields, if any
        userRepository.save(existingUser);
    }

    public Optional<UsersModel> findById(Integer id) {
        return userRepository.findById(id);
    }

    public UsersModel save(UsersModel user) {
        return userRepository.save(user);
    }

    public void deactivateUser(Integer userId) {
        userRepository.deleteById(userId);
    }


    public Optional<UsersModel> findByLogin(String username) {
        return userRepository.findByLogin(username);
    }

}
