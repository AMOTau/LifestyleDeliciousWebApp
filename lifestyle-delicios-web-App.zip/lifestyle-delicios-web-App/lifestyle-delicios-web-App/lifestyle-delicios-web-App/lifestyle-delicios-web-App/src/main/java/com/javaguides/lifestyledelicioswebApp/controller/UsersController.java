package com.javaguides.lifestyledelicioswebApp.controller;


import com.javaguides.lifestyledelicioswebApp.model.UsersModel;
import com.javaguides.lifestyledelicioswebApp.service.UsersService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.security.core.Authentication;

import java.util.Optional;


@Controller
public class UsersController {

    private final UsersService usersService;

    private static final Logger logger = LoggerFactory.getLogger(UsersController.class);

    public UsersController(UsersService usersService) {
        this.usersService = usersService;
    }

    @GetMapping("/sign_in")
    public String signIn(Model model) {
        model.addAttribute("registerRequest",new UsersModel());
        return "sign_in";
    }

    @PostMapping("/sign_in")
    public String signInPost(@ModelAttribute UsersModel usersModel) {
        System.out.println("register request "+usersModel);

        UsersModel registeredUser=  usersService.registerUser(usersModel.getLogin(),usersModel.getPassword(),usersModel.getEmail(),usersModel.getName(),usersModel.getSurname(),usersModel.getPhoneNumber());

        return  registeredUser == null?"error_page" : "redirect:/login";


    }

    @GetMapping("/login")
    public String login(Model model) {
        model.addAttribute("loginRequest",new UsersModel());
        return "login";
    }

    @GetMapping("/edit_profile")
    public String editProfile(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName(); // Get logged-in username

        Optional<UsersModel> userOpt = usersService.findByLogin(username);
        if (userOpt.isPresent()) {
            model.addAttribute("user", userOpt.get());
            return "edit_profile"; // The name of your Thymeleaf template
        } else {
            // Handle the case where the user isn't found
            model.addAttribute("errorMessage", "User not found");
            return "error_page"; // The name of an error view
        }
    }

    @PostMapping("/login")
    public String loginPost(@ModelAttribute UsersModel usersModel,Model model) {
        System.out.println("login request "+usersModel);

        UsersModel aunthenticate=  usersService.authenticate(usersModel.getLogin(),usersModel.getPassword());

        if(aunthenticate!=null) {
            model.addAttribute("userLogin",aunthenticate.getLogin());
            return "menu";
        }
        else
        {
            return "error_page";
        }


    }

    // ... other controller methods ...

    @PostMapping("/deactivate")
    public String deactivateAccount(Model model) {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        String username = auth.getName(); // Get logged-in username

        logger.info("Attempting to deactivate account for user: {}", username);

        Optional<UsersModel> userOpt = usersService.findByLogin(username);
        if (userOpt.isPresent()) {
            try {
                usersService.deactivateUser(userOpt.get().getId());
                SecurityContextHolder.clearContext(); // Clear the security context (logout the user)
                logger.info("Account successfully deactivated for user: {}", username);
                return "redirect:/login?deactivated=true";
            } catch (Exception e) {
                logger.error("An error occurred during the deactivation process for user: {}", username, e);
                model.addAttribute("errorMessage", "An unexpected error occurred. Please try again.");
                return "error_page";
            }
        } else {
            logger.error("User not found with username: {}", username);
            model.addAttribute("errorMessage", "User not found");
            return "error_page";
        }
    }

    @GetMapping("/about")
    public String about() {
        return "about";
    }

    @GetMapping("/contact")
    public String contact() {
        return "contact";
    }

    @GetMapping("/forgot_password")
    public String forgot_password() {
        return "forgot_password";
    }

    @GetMapping("index")
    public String showHomePage(){
        return "index";
    }

    @GetMapping("/menu")
    public String menu() {
        return "menu";
    }

    @GetMapping("/pay")
    public String pay() {
        return "pay";
    }

    @GetMapping("/summary")
    public String summary() {
        return "summary";
    }

    @GetMapping("/home")
    public String home() {
        return "home";
    }

    @GetMapping("/sign_out")
    public String sign_out() {
        return "sign_out";
    }



    @GetMapping("/profile_updated")
    public String profileUpdated() {
        return "profile_updated";
    }

    @GetMapping("/deactivate_account")
    public String deactivate_account() {
        return "deactivate_account";
    }
    // Endpoint to handle deactivating a user account


    @PostMapping("/edit_user")
    public String updateProfile(@RequestParam(required = false) String phone,
                                @RequestParam(required = false) String surname, Model model) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            String username = auth.getName(); // Get logged in username

            Optional<UsersModel> userOpt = usersService.findByLogin(username);
            if (!userOpt.isPresent()) {
                throw new UsernameNotFoundException("User not found with username: " + username);
            }

            UsersModel user = userOpt.get();
            if (phone != null && !phone.isEmpty()) {
                user.setPhoneNumber(phone);
            }
            if (surname != null && !surname.isEmpty()) {
                user.setSurname(surname);
            }

            usersService.save(user);
            logger.info("Profile updated, redirecting to profile_updated");
            return "redirect:/profile_updated"; // Redirect to the profile page after update
        } catch (UsernameNotFoundException e) {
            logger.error("User not found", e);
            model.addAttribute("errorMessage", e.getMessage());
            return "error_page";
        }
    }
}